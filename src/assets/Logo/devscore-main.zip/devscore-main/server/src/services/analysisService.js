const GITHUB_API_BASE_URL = 'https://api.github.com'
const LEETCODE_API_URL = 'https://leetcode.com/graphql/'
const GITHUB_API_VERSION = '2022-11-28'

class ProfileLookupError extends Error {
  constructor(message, statusCode = 500) {
    super(message)
    this.name = 'ProfileLookupError'
    this.statusCode = statusCode
  }
}

function clamp(value, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value))
}

function ratioToScore(value, maxValue) {
  if (!value || value <= 0) {
    return 0
  }

  return clamp((value / maxValue) * 100)
}

function sum(values) {
  return values.reduce((total, value) => total + value, 0)
}

function daysBetween(dateString) {
  const now = Date.now()
  const dateValue = new Date(dateString).getTime()
  return Math.floor((now - dateValue) / (1000 * 60 * 60 * 24))
}

async function fetchJson(url, options = {}, notFoundMessage) {
  const response = await fetch(url, options)

  if (response.status === 404 && notFoundMessage) {
    throw new ProfileLookupError(notFoundMessage, 404)
  }

  if (!response.ok) {
    throw new ProfileLookupError(`Failed to fetch profile data (${response.status}).`, response.status)
  }

  return response.json()
}

async function fetchGitHubProfile(username) {
  const headers = {
    Accept: 'application/vnd.github+json',
    'User-Agent': 'DevScore-MVP',
    'X-GitHub-Api-Version': GITHUB_API_VERSION,
  }

  if (process.env.GITHUB_TOKEN) {
    headers.Authorization = `Bearer ${process.env.GITHUB_TOKEN}`
  }

  const [profile, repos] = await Promise.all([
    fetchJson(
      `${GITHUB_API_BASE_URL}/users/${encodeURIComponent(username)}`,
      { headers },
      `GitHub user "${username}" was not found.`,
    ),
    fetchJson(
      `${GITHUB_API_BASE_URL}/users/${encodeURIComponent(username)}/repos?per_page=100&sort=updated`,
      { headers },
      `GitHub repositories for "${username}" were not found.`,
    ),
  ])

  return { profile, repos }
}

async function fetchLeetCodeProfile(username) {
  const response = await fetch(LEETCODE_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Referer: 'https://leetcode.com',
    },
    body: JSON.stringify({
      query: `
        query userPublicProfile($username: String!) {
          matchedUser(username: $username) {
            username
            profile {
              ranking
              reputation
              starRating
              userAvatar
            }
            submitStats {
              acSubmissionNum {
                difficulty
                count
                submissions
              }
            }
            badges {
              id
              displayName
            }
          }
          userContestRanking(username: $username) {
            attendedContestsCount
            rating
            globalRanking
            topPercentage
          }
        }
      `,
      variables: { username },
    }),
  })

  if (!response.ok) {
    throw new ProfileLookupError(`Failed to fetch LeetCode profile data (${response.status}).`, response.status)
  }

  const payload = await response.json()

  if (!payload?.data?.matchedUser) {
    throw new ProfileLookupError(`LeetCode user "${username}" was not found.`, 404)
  }

  return payload.data
}

function buildGitHubInsights(profile, repos, metrics) {
  const strengths = []
  const weaknesses = []
  const suggestions = []

  if (metrics.activityScore >= 65) {
    strengths.push('Consistent GitHub activity across recently updated repositories')
  } else {
    weaknesses.push('Recent GitHub activity is limited or uneven')
    suggestions.push('Ship or update projects regularly to show current momentum')
  }

  if (metrics.repoDepthScore >= 60) {
    strengths.push('Healthy public repository depth with visible project output')
  } else {
    weaknesses.push('Public repository depth is still developing')
    suggestions.push('Publish 2-3 polished repositories that showcase real product work')
  }

  if (metrics.impactScore >= 55) {
    strengths.push('Strong open-source visibility through stars and followers')
  } else {
    weaknesses.push('Open-source impact is not yet strongly visible')
    suggestions.push('Invest in README quality and project presentation to improve discoverability')
  }

  if (!repos.some((repo) => repo.stargazers_count > 0)) {
    suggestions.push('Promote your strongest project so it earns external validation')
  }

  return { strengths, weaknesses, suggestions }
}

function buildLeetCodeInsights(leetCodeData, metrics) {
  const strengths = []
  const weaknesses = []
  const suggestions = []

  if (metrics.problemDepthScore >= 65) {
    strengths.push('Strong solved-problem volume across multiple difficulty levels')
  } else {
    weaknesses.push('Solved-problem volume is still modest for a standout DSA signal')
    suggestions.push('Increase solved counts steadily across easy, medium, and hard tracks')
  }

  if (metrics.contestScore >= 55) {
    strengths.push('Contest performance adds credible competitive coding signal')
  } else {
    weaknesses.push('Contest performance signal is limited or missing')
    suggestions.push('Join weekly contests to build measurable problem-solving depth')
  }

  if ((leetCodeData.matchedUser.badges?.length ?? 0) >= 3) {
    strengths.push('Badge history shows strong consistency on the platform')
  } else {
    suggestions.push('Build a challenge streak to make consistency more visible on LeetCode')
  }

  return { strengths, weaknesses, suggestions }
}

function scoreGitHubProfile(profile, repos) {
  const ownedRepos = repos.filter((repo) => !repo.fork)
  const totalStars = sum(ownedRepos.map((repo) => repo.stargazers_count))
  const totalForks = sum(ownedRepos.map((repo) => repo.forks_count))
  const recentlyUpdatedRepos = ownedRepos.filter((repo) => daysBetween(repo.pushed_at) <= 365).length
  const originalRepoRatio = ownedRepos.length / Math.max(repos.length, 1)
  const accountAgeYears = Math.max(daysBetween(profile.created_at) / 365, 0.2)

  const repoDepthScore =
    ratioToScore(profile.public_repos, 20) * 0.55 +
    ratioToScore(ownedRepos.length, 12) * 0.45

  const impactScore =
    ratioToScore(profile.followers, 300) * 0.4 +
    ratioToScore(totalStars, 150) * 0.4 +
    ratioToScore(totalForks, 50) * 0.2

  const activityScore =
    ratioToScore(recentlyUpdatedRepos, 8) * 0.65 +
    ratioToScore(originalRepoRatio, 1) * 0.2 +
    ratioToScore(accountAgeYears, 4) * 0.15

  const githubScore = Math.round(
    repoDepthScore * 0.38 + impactScore * 0.37 + activityScore * 0.25,
  )

  return {
    githubScore: clamp(githubScore),
    metrics: {
      repoDepthScore: clamp(Math.round(repoDepthScore)),
      impactScore: clamp(Math.round(impactScore)),
      activityScore: clamp(Math.round(activityScore)),
      totalStars,
      totalForks,
      ownedRepos: ownedRepos.length,
      recentlyUpdatedRepos,
    },
  }
}

function scoreLeetCodeProfile(leetCodeData) {
  const solvedByDifficulty = Object.fromEntries(
    (leetCodeData.matchedUser.submitStats?.acSubmissionNum ?? []).map((entry) => [entry.difficulty, entry]),
  )

  const easySolved = solvedByDifficulty.Easy?.count ?? 0
  const mediumSolved = solvedByDifficulty.Medium?.count ?? 0
  const hardSolved = solvedByDifficulty.Hard?.count ?? 0
  const totalSolved = solvedByDifficulty.All?.count ?? 0
  const badgesCount = leetCodeData.matchedUser.badges?.length ?? 0
  const contestRanking = leetCodeData.userContestRanking

  const problemDepthScore =
    ratioToScore(easySolved, 150) * 0.2 +
    ratioToScore(mediumSolved, 250) * 0.45 +
    ratioToScore(hardSolved, 80) * 0.35

  const contestScore = contestRanking
    ? ratioToScore(contestRanking.rating ?? 0, 2200) * 0.65 +
      ratioToScore(contestRanking.attendedContestsCount ?? 0, 12) * 0.2 +
      ratioToScore(100 - Math.min(contestRanking.topPercentage ?? 100, 100), 100) * 0.15
    : 0

  const consistencyScore =
    ratioToScore(totalSolved, 500) * 0.7 +
    ratioToScore(badgesCount, 8) * 0.3

  const leetcodeScore = Math.round(
    problemDepthScore * 0.5 + contestScore * 0.3 + consistencyScore * 0.2,
  )

  return {
    leetcodeScore: clamp(leetcodeScore),
    metrics: {
      problemDepthScore: clamp(Math.round(problemDepthScore)),
      contestScore: clamp(Math.round(contestScore)),
      consistencyScore: clamp(Math.round(consistencyScore)),
      totalSolved,
      easySolved,
      mediumSolved,
      hardSolved,
      badgesCount,
      contestRating: contestRanking?.rating ?? null,
    },
  }
}

function dedupe(items) {
  return [...new Set(items)].slice(0, 4)
}

export async function analyzeDeveloperProfile({ github, leetcode }) {
  const [githubData, leetCodeData] = await Promise.all([
    fetchGitHubProfile(github),
    fetchLeetCodeProfile(leetcode),
  ])

  const githubScoreData = scoreGitHubProfile(githubData.profile, githubData.repos)
  const leetCodeScoreData = scoreLeetCodeProfile(leetCodeData)

  const combinedScore = Math.round(
    githubScoreData.githubScore * 0.52 + leetCodeScoreData.leetcodeScore * 0.48,
  )

  const githubInsights = buildGitHubInsights(
    githubData.profile,
    githubData.repos,
    githubScoreData.metrics,
  )
  const leetCodeInsights = buildLeetCodeInsights(leetCodeData, leetCodeScoreData.metrics)

  return {
    score: clamp(combinedScore),
    githubScore: githubScoreData.githubScore,
    leetcodeScore: leetCodeScoreData.leetcodeScore,
    strengths: dedupe([...githubInsights.strengths, ...leetCodeInsights.strengths]),
    weaknesses: dedupe([...githubInsights.weaknesses, ...leetCodeInsights.weaknesses]),
    suggestions: dedupe([...githubInsights.suggestions, ...leetCodeInsights.suggestions]),
    details: {
      github: githubScoreData.metrics,
      leetcode: leetCodeScoreData.metrics,
    },
  }
}

export { ProfileLookupError }
