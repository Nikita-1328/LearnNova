import { Router } from 'express'
import { analyzeProfile } from '../controllers/analysisController.js'

const analysisRouter = Router()

analysisRouter.post('/analyze', analyzeProfile)

export default analysisRouter
