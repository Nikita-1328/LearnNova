import express from 'express'
import cors from 'cors'
import analysisRouter from './routes/analysisRoutes.js'

const app = express()

app.use(cors())
app.use(express.json())

app.get('/health', (_request, response) => {
  response.status(200).json({ status: 'ok' })
})

app.use('/', analysisRouter)

export default app
