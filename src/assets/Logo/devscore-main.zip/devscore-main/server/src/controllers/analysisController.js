import { analyzeDeveloperProfile, ProfileLookupError } from '../services/analysisService.js'

export async function analyzeProfile(request, response) {
  const { github, leetcode } = request.body

  if (!github || !leetcode) {
    return response.status(400).json({
      message: 'GitHub and LeetCode usernames are required.',
    })
  }

  try {
    const result = await analyzeDeveloperProfile({
      github: github.trim(),
      leetcode: leetcode.trim(),
    })

    return response.status(200).json(result)
  } catch (error) {
    if (error instanceof ProfileLookupError) {
      return response.status(error.statusCode).json({
        message: error.message,
      })
    }

    return response.status(500).json({
      message: 'Unable to analyze the provided profiles right now.',
    })
  }
}
