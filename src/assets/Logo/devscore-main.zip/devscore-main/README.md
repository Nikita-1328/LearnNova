# DevScore

DevScore is a full-stack MVP that turns a developer's public GitHub and LeetCode activity into a single reputation score with strengths, weaknesses, and practical suggestions.

The app is designed for fast profile snapshots and portfolio storytelling:

- Frontend: polished React UI with analysis and history views
- Backend: Express API that fetches public profile data and computes weighted metrics
- Output: combined score plus explainable category breakdowns

## Highlights

- Analyze two handles in one request (`github`, `leetcode`)
- Weighted score model (GitHub + LeetCode)
- Insight generation: strengths, weaknesses, and suggestions
- Session-based analysis history on the client
- Dockerized local stack for one-command startup

## Architecture

```mermaid
flowchart LR
		U[User] --> C[React Client<br/>Vite + Tailwind]
		C -->|POST /analyze| S[Express Server]

		S -->|REST| GH[GitHub API]
		S -->|GraphQL| LC[LeetCode API]

		GH --> S
		LC --> S
		S -->|Score + Insights JSON| C
		C --> R[Result View + Dashboard History]
```

## Request Lifecycle

```mermaid
sequenceDiagram
		autonumber
		participant User
		participant Client as React Client
		participant API as Express API
		participant GitHub as GitHub API
		participant LeetCode as LeetCode GraphQL

		User->>Client: Submit GitHub + LeetCode usernames
		Client->>API: POST /analyze
		API->>GitHub: GET /users/:username + repos
		API->>LeetCode: POST /graphql (public profile query)
		GitHub-->>API: Profile + repositories
		LeetCode-->>API: Stats + contest/badge data
		API->>API: Compute metrics and weighted scores
		API-->>Client: score + category scores + insights
		Client-->>User: Result page + saved history entry
```

## Scoring Pipeline

```mermaid
flowchart TD
		A[Input Usernames] --> B[Fetch GitHub Data]
		A --> C[Fetch LeetCode Data]

		B --> D[GitHub Metrics<br/>Repo Depth, Impact, Activity]
		C --> E[LeetCode Metrics<br/>Problem Depth, Contest, Consistency]

		D --> F[GitHub Score]
		E --> G[LeetCode Score]

		F --> H[Combined Score<br/>0.52 * GitHub + 0.48 * LeetCode]
		G --> H

		H --> I[Strengths]
		H --> J[Weaknesses]
		H --> K[Suggestions]
```

## Tech Stack

- Client: React 19, Vite 8, Tailwind CSS 4
- Server: Node.js, Express 5
- APIs: GitHub REST API, LeetCode GraphQL API
- Containers: Docker, Docker Compose

## Repository Structure

```text
devscore/
|- client/                  # React application
|  |- src/
|  |  |- pages/             # Landing, Analyze, Result, Dashboard
|  |  |- components/        # Reusable UI blocks
|  |  |- services/api.js    # API client for backend calls
|  |  |- hooks/             # Routing + local history helpers
|- server/                  # Express API
|  |- src/
|  |  |- routes/            # HTTP route definitions
|  |  |- controllers/       # Input validation + response handling
|  |  |- services/          # External fetch + scoring logic
|- docker-compose.yml       # Multi-container local setup
```

## API Contract

### `POST /analyze`

Request body:

```json
{
  "github": "octocat",
  "leetcode": "some-handle"
}
```

Successful response shape:

```json
{
  "score": 78,
  "githubScore": 80,
  "leetcodeScore": 76,
  "strengths": ["..."],
  "weaknesses": ["..."],
  "suggestions": ["..."],
  "details": {
    "github": {
      "repoDepthScore": 0,
      "impactScore": 0,
      "activityScore": 0,
      "totalStars": 0,
      "totalForks": 0,
      "ownedRepos": 0,
      "recentlyUpdatedRepos": 0
    },
    "leetcode": {
      "problemDepthScore": 0,
      "contestScore": 0,
      "consistencyScore": 0,
      "totalSolved": 0,
      "easySolved": 0,
      "mediumSolved": 0,
      "hardSolved": 0,
      "badgesCount": 0,
      "contestRating": null
    }
  }
}
```

Error response:

```json
{
  "message": "GitHub and LeetCode usernames are required."
}
```

### `GET /health`

Returns:

```json
{ "status": "ok" }
```

## Environment Variables

Client (`client`):

- `VITE_API_BASE_URL` (optional): API base URL, defaults to `http://localhost:5000`

Server (`server`):

- `PORT` (optional): server port, defaults to `5000`
- `GITHUB_TOKEN` (optional): increases GitHub API rate limits

## Local Development

### 1) Start the server

```bash
cd server
npm install
npm run dev
```

Server runs on `http://localhost:5000`.

### 2) Start the client

```bash
cd client
pnpm install
pnpm dev
```

Client runs on `http://localhost:5173`.

## Docker

Run both services together:

```bash
docker compose up --build
```

Services:

- Client: `http://localhost:5173`
- Server: `http://localhost:5000`

## Useful Scripts

Client (`client/package.json`):

- `pnpm dev` - run Vite dev server
- `pnpm build` - production build
- `pnpm preview` - preview built app
- `pnpm lint` - run ESLint

Server (`server/package.json`):

- `npm run dev` - run with file watching
- `npm run start` - run in normal mode

## Current Limitations

- No authentication or user accounts (public handles only)
- No persistent backend storage (history is client-side)
- LeetCode data availability depends on public profile visibility
- Score model is heuristic and intended for MVP insights

## Roadmap Ideas

- Add persistence and shareable report links
- Add trend snapshots over time
- Add richer repo-level NLP insights
- Add tests and CI pipeline
