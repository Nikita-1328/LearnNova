function ScoreRing({ score, size = 'large' }) {
  const dimensions = size === 'large' ? 'h-56 w-56 text-6xl' : 'h-32 w-32 text-3xl'
  const circleLength = 339.292
  const dashOffset = circleLength - (circleLength * score) / 100

  return (
    <div className={`relative inline-flex items-center justify-center ${dimensions}`}>
      <svg className="absolute inset-0 -rotate-90" viewBox="0 0 120 120" aria-hidden="true">
        <circle cx="60" cy="60" r="54" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="8" />
        <circle
          cx="60"
          cy="60"
          r="54"
          fill="none"
          stroke="url(#scoreGradient)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={circleLength}
          strokeDashoffset={dashOffset}
        />
        <defs>
          <linearGradient id="scoreGradient" x1="0%" x2="100%" y1="0%" y2="100%">
            <stop offset="0%" stopColor="#7fe3ff" />
            <stop offset="55%" stopColor="#58e7c1" />
            <stop offset="100%" stopColor="#ffbf69" />
          </linearGradient>
        </defs>
      </svg>

      <div className="glass-card flex h-[78%] w-[78%] flex-col items-center justify-center rounded-full">
        <span className="font-display font-bold text-white">{score}</span>
        <span className="mt-2 text-xs uppercase tracking-[0.3em] text-slate-400">DevScore</span>
      </div>
    </div>
  )
}

export default ScoreRing
