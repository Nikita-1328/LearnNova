function StatBar({ label, value, tone = 'primary' }) {
  const colors = {
    primary: 'from-cyan-300 via-sky-300 to-emerald-300',
    secondary: 'from-amber-300 via-orange-300 to-rose-300',
  }

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-4">
      <div className="mb-3 flex items-center justify-between text-sm text-slate-300">
        <span>{label}</span>
        <span className="font-semibold text-white">{value}/100</span>
      </div>
      <div className="h-3 overflow-hidden rounded-full bg-white/8">
        <div
          className={`h-full rounded-full bg-gradient-to-r ${colors[tone]}`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  )
}

export default StatBar
