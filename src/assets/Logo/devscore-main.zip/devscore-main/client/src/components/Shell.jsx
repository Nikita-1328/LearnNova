import { useRoute } from '../hooks/useRoute'

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/analyze', label: 'Analyze' },
  { to: '/dashboard', label: 'Dashboard' },
]

function Shell({ children }) {
  const { pathname, navigate } = useRoute()

  return (
    <div className="relative min-h-screen overflow-hidden">
      <div className="pointer-events-none absolute inset-0 grid-bg opacity-50" />
      <div className="pointer-events-none absolute left-[-6rem] top-24 h-56 w-56 rounded-full bg-cyan-300/15 blur-3xl" />
      <div className="pointer-events-none absolute right-[-3rem] top-12 h-72 w-72 rounded-full bg-emerald-300/12 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-1/3 h-64 w-64 rounded-full bg-amber-300/10 blur-3xl" />

      <header className="relative z-10 mx-auto flex w-full max-w-7xl items-center justify-between px-6 py-6 lg:px-10">
        <button
          type="button"
          onClick={() => navigate('/')}
          className="font-display cursor-pointer text-xl font-bold tracking-tight text-white"
        >
          Dev<span className="text-gradient">Score</span>
        </button>

        <nav className="glass-card hidden items-center gap-2 rounded-full px-3 py-2 text-sm text-slate-200 md:flex">
          {navLinks.map((link) => (
            <button
              key={link.to}
              type="button"
              onClick={() => navigate(link.to)}
              className={`rounded-full px-4 py-2 transition ${
                pathname === link.to ? 'bg-white/10 text-white' : 'text-slate-300 hover:bg-white/5 hover:text-white'
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        <button
          type="button"
          onClick={() => navigate('/analyze')}
          className="rounded-full border border-white/12 bg-white/8 px-4 py-2 text-sm font-semibold text-white transition hover:-translate-y-0.5 hover:bg-white/14"
        >
          Start Scan
        </button>
      </header>

      <main className="relative z-10">{children}</main>
    </div>
  )
}

export default Shell
