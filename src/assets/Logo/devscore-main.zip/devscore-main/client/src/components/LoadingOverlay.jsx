function LoadingOverlay() {
  return (
    <div className="glass-card absolute inset-0 flex flex-col items-center justify-center rounded-[32px]">
      <div className="relative h-20 w-20">
        <div className="animate-pulse-soft absolute inset-0 rounded-full border border-cyan-200/30" />
        <div className="absolute inset-3 rounded-full border-4 border-transparent border-t-cyan-300 border-r-emerald-300 animate-spin" />
      </div>
      <p className="mt-6 font-display text-xl font-semibold text-white">Analyzing your developer signal</p>
      <p className="mt-2 max-w-sm text-center text-sm text-slate-300">
        Scoring profile consistency, repo quality, and coding depth from your submitted handles.
      </p>
    </div>
  )
}

export default LoadingOverlay
