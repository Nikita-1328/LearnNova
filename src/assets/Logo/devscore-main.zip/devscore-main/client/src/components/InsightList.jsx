function InsightList({ title, items, tone = 'success' }) {
  const styles = {
    success: 'bg-emerald-300/10 text-emerald-100 ring-emerald-300/20',
    warning: 'bg-amber-300/10 text-amber-100 ring-amber-300/20',
    info: 'bg-cyan-300/10 text-cyan-100 ring-cyan-300/20',
  }

  return (
    <div className="glass-card rounded-[28px] p-6">
      <h3 className="font-display text-xl font-semibold text-white">{title}</h3>
      <div className="mt-5 space-y-3">
        {items.map((item) => (
          <div key={item} className={`rounded-2xl px-4 py-3 text-sm ring-1 ${styles[tone]}`}>
            {item}
          </div>
        ))}
      </div>
    </div>
  )
}

export default InsightList
