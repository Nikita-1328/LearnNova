export function formatHandle(handle) {
  return handle?.trim() ? `@${handle.trim()}` : 'Not provided'
}

export function getScoreLabel(score) {
  if (score >= 85) {
    return 'Elite momentum'
  }

  if (score >= 70) {
    return 'High potential'
  }

  if (score >= 55) {
    return 'Promising foundation'
  }

  return 'Early signal'
}
