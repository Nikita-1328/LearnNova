import { useRoute } from './hooks/useRoute'
import LandingPage from './pages/LandingPage'
import AnalyzePage from './pages/AnalyzePage'
import ResultPage from './pages/ResultPage'
import DashboardPage from './pages/DashboardPage'

function App() {
  const { pathname } = useRoute()

  if (pathname === '/analyze') {
    return <AnalyzePage />
  }

  if (pathname === '/result') {
    return <ResultPage />
  }

  if (pathname === '/dashboard') {
    return <DashboardPage />
  }

  return <LandingPage />
}

export default App
