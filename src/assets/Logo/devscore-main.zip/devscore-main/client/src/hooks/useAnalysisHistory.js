const STORAGE_KEY = 'devscore.history'

export function readAnalysisHistory() {
  const raw = window.localStorage.getItem(STORAGE_KEY)

  if (!raw) {
    return []
  }

  try {
    return JSON.parse(raw)
  } catch {
    return []
  }
}

export function saveAnalysisEntry(entry) {
  const current = readAnalysisHistory()
  const next = [entry, ...current].slice(0, 6)
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
}
