import { createContext, createElement, useContext, useEffect, useState } from 'react'

const ROUTE_STATE_KEY = 'devscore.routeState'
const RouteContext = createContext(null)

function readRouteState() {
  const historyState = window.history.state

  if (historyState?.devscore) {
    return historyState.devscore
  }

  const storedValue = window.sessionStorage.getItem(ROUTE_STATE_KEY)
  if (!storedValue) {
    return null
  }

  try {
    return JSON.parse(storedValue)
  } catch {
    return null
  }
}

export function RouteProvider({ children }) {
  const [route, setRoute] = useState(() => ({
    pathname: window.location.pathname,
    routeState: readRouteState(),
  }))

  useEffect(() => {
    function syncRoute() {
      setRoute({
        pathname: window.location.pathname,
        routeState: readRouteState(),
      })
    }

    window.addEventListener('popstate', syncRoute)
    return () => window.removeEventListener('popstate', syncRoute)
  }, [])

  function navigate(pathname, routeState = null) {
    const nextState = routeState ? { devscore: routeState } : null

    if (routeState) {
      window.sessionStorage.setItem(ROUTE_STATE_KEY, JSON.stringify(routeState))
    } else {
      window.sessionStorage.removeItem(ROUTE_STATE_KEY)
    }

    window.history.pushState(nextState, '', pathname)
    setRoute({ pathname, routeState })
  }

  return createElement(
    RouteContext.Provider,
    {
      value: {
        pathname: route.pathname,
        routeState: route.routeState,
        navigate,
      },
    },
    children,
  )
}

export function useRoute() {
  const value = useContext(RouteContext)

  if (!value) {
    throw new Error('useRoute must be used within a RouteProvider.')
  }

  return value
}
