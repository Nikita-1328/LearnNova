import Shell from '../components/Shell'
import ScoreRing from '../components/ScoreRing'
import { readAnalysisHistory } from '../hooks/useAnalysisHistory'
import { useRoute } from '../hooks/useRoute'
import { formatHandle } from '../utils/formatters'

function DashboardPage() {
  const { navigate } = useRoute()
  const history = readAnalysisHistory()

  return (
    <Shell>
      <section className="mx-auto max-w-7xl px-6 pb-24 pt-8 lg:px-10">
        <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.32em] text-cyan-200/75">Dashboard</p>
            <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight text-white">Past analysis snapshots</h1>
            <p className="mt-4 max-w-2xl text-base leading-7 text-slate-300">
              Local mock history keeps the MVP feeling real and gives us a clean extension point for a future authenticated dashboard.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/analyze')}
            className="aurora-ring glass-card rounded-full px-6 py-4 text-sm font-semibold text-white transition hover:-translate-y-1"
          >
            New Analysis
          </button>
        </div>

        <div className="grid gap-6">
          {history.length ? (
            history.map((entry) => (
              <div key={`${entry.github}-${entry.createdAt}`} className="glass-card grid gap-6 rounded-[32px] p-6 lg:grid-cols-[0.32fr_1fr]">
                <div className="flex items-center justify-center">
                  <ScoreRing score={entry.score} size="small" />
                </div>
                <div className="grid gap-5 md:grid-cols-[0.9fr_1.1fr]">
                  <div>
                    <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Handles</p>
                    <p className="mt-3 text-lg font-semibold text-white">
                      {formatHandle(entry.github)} / {formatHandle(entry.leetcode)}
                    </p>
                    <p className="mt-3 text-sm text-slate-400">
                      {new Date(entry.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="grid gap-3 sm:grid-cols-3">
                    {[
                      `GitHub ${entry.githubScore}`,
                      `LeetCode ${entry.leetcodeScore}`,
                      entry.suggestions[0],
                    ].map((item) => (
                      <div key={item} className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 text-sm text-slate-200">
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="glass-card rounded-[32px] p-10 text-center">
              <h2 className="font-display text-2xl font-semibold text-white">No analyses yet</h2>
              <p className="mt-3 text-sm text-slate-300">Run your first mock analysis to populate the dashboard.</p>
            </div>
          )}
        </div>
      </section>
    </Shell>
  )
}

export default DashboardPage
