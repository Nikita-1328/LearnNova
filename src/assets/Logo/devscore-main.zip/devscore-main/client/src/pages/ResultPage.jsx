import { useEffect } from 'react'
import InsightList from '../components/InsightList'
import ScoreRing from '../components/ScoreRing'
import Shell from '../components/Shell'
import StatBar from '../components/StatBar'
import { useRoute } from '../hooks/useRoute'
import { formatHandle, getScoreLabel } from '../utils/formatters'

function ResultPage() {
  const { navigate, routeState: state } = useRoute()

  useEffect(() => {
    if (!state) {
      navigate('/analyze')
    }
  }, [navigate, state])

  if (!state) {
    return null
  }

  return (
    <Shell>
      <section className="mx-auto max-w-7xl px-6 pb-24 pt-8 lg:px-10">
        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="glass-card rounded-[34px] p-8">
            <p className="text-sm uppercase tracking-[0.32em] text-cyan-200/75">Result</p>
            <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight text-white">Your developer reputation snapshot</h1>
            <p className="mt-4 text-base leading-7 text-slate-300">
              Built from the combined signal of {formatHandle(state.github)} and {formatHandle(state.leetcode)}.
            </p>

            <div className="mt-10 flex justify-center">
              <ScoreRing score={state.score} />
            </div>

            <div className="mt-8 rounded-[28px] border border-white/10 bg-white/[0.04] p-5 text-center">
              <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Positioning</p>
              <p className="mt-3 font-display text-2xl font-semibold text-white">{getScoreLabel(state.score)}</p>
              <p className="mt-2 text-sm text-slate-300">A concise summary of current visibility, consistency, and problem-solving depth.</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="glass-card rounded-[34px] p-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm uppercase tracking-[0.32em] text-slate-500">Breakdown</p>
                  <h2 className="mt-3 font-display text-3xl font-semibold text-white">Score components</h2>
                </div>
                <button
                  type="button"
                  onClick={() => navigate('/analyze')}
                  className="rounded-full border border-white/10 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/6"
                >
                  Re-run
                </button>
              </div>

              <div className="mt-8 space-y-4">
                <StatBar label="GitHub Score" value={state.githubScore} />
                <StatBar label="Problem Solving Score" value={state.leetcodeScore} tone="secondary" />
              </div>
            </div>

            <div className="grid gap-6 xl:grid-cols-3">
              <InsightList title="Strengths" items={state.strengths} tone="success" />
              <InsightList title="Weaknesses" items={state.weaknesses} tone="warning" />
              <InsightList title="Suggestions" items={state.suggestions} tone="info" />
            </div>
          </div>
        </div>
      </section>
    </Shell>
  )
}

export default ResultPage
