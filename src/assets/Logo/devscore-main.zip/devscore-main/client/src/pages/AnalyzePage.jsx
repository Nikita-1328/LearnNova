import { useState } from 'react'
import LoadingOverlay from '../components/LoadingOverlay'
import Shell from '../components/Shell'
import { useRoute } from '../hooks/useRoute'
import { analyzeDeveloper } from '../services/api'
import { saveAnalysisEntry } from '../hooks/useAnalysisHistory'

const initialForm = {
  github: '',
  leetcode: '',
}

function AnalyzePage() {
  const { navigate } = useRoute()
  const [form, setForm] = useState(initialForm)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  function handleChange(event) {
    const { name, value } = event.target
    setForm((current) => ({ ...current, [name]: value }))
  }

  async function handleSubmit(event) {
    event.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      const data = await analyzeDeveloper(form)
      const historyEntry = {
        ...data,
        github: form.github,
        leetcode: form.leetcode,
        createdAt: new Date().toISOString(),
      }

      saveAnalysisEntry(historyEntry)
      navigate('/result', historyEntry)
    } catch (submissionError) {
      setError(submissionError.message)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Shell>
      <section className="mx-auto max-w-5xl px-6 pb-24 pt-10 lg:px-10">
        <div className="mb-10 max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-[0.32em] text-cyan-200/75">Analyze</p>
          <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight text-white sm:text-5xl">
            Turn usernames into a developer reputation snapshot.
          </h1>
          <p className="mt-4 text-base leading-7 text-slate-300">
            Submit your GitHub and LeetCode handles. We’ll call the mock backend, simulate analysis, and generate a polished score report.
          </p>
        </div>

        <div className="relative">
          <form onSubmit={handleSubmit} className="glass-card grid gap-8 rounded-[32px] p-8 lg:grid-cols-[1.1fr_0.9fr] lg:p-10">
            <div className="space-y-6">
              <div>
                <label htmlFor="github" className="mb-3 block text-sm font-medium text-slate-200">
                  GitHub Username
                </label>
                <input
                  id="github"
                  name="github"
                  value={form.github}
                  onChange={handleChange}
                  placeholder="e.g. octocat"
                  required
                  className="w-full rounded-2xl border border-white/10 bg-slate-950/40 px-5 py-4 text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-300/50"
                />
              </div>

              <div>
                <label htmlFor="leetcode" className="mb-3 block text-sm font-medium text-slate-200">
                  LeetCode Username
                </label>
                <input
                  id="leetcode"
                  name="leetcode"
                  value={form.leetcode}
                  onChange={handleChange}
                  placeholder="e.g. problemcrusher"
                  required
                  className="w-full rounded-2xl border border-white/10 bg-slate-950/40 px-5 py-4 text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-300/50"
                />
              </div>

              {error ? (
                <div className="rounded-2xl border border-rose-300/20 bg-rose-300/10 px-4 py-3 text-sm text-rose-100">
                  {error}
                </div>
              ) : null}

              <button
                type="submit"
                disabled={isLoading}
                className="aurora-ring glass-card w-full rounded-full px-6 py-4 text-sm font-semibold text-white transition hover:-translate-y-1 disabled:cursor-not-allowed disabled:opacity-70"
              >
                {isLoading ? 'Analyzing...' : 'Generate DevScore'}
              </button>
            </div>

            <div className="rounded-[28px] border border-white/10 bg-slate-950/30 p-6">
              <p className="text-sm uppercase tracking-[0.32em] text-slate-500">Included in the scan</p>
              <div className="mt-6 space-y-4">
                {[
                  'Repository consistency and visible output',
                  'Problem solving performance signal',
                  'Strength and weakness clustering',
                  'Actionable portfolio suggestions',
                ].map((item) => (
                  <div key={item} className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-4 text-sm text-slate-200">
                    {item}
                  </div>
                ))}
              </div>
            </div>
          </form>

          {isLoading ? <LoadingOverlay /> : null}
        </div>
      </section>
    </Shell>
  )
}

export default AnalyzePage
