import Shell from '../components/Shell'
import SectionHeading from '../components/SectionHeading'
import { useRoute } from '../hooks/useRoute'

const steps = [
  { title: 'Connect GitHub', copy: 'Submit your public username and let DevScore inspect your visible developer footprint.' },
  { title: 'Analyze Code', copy: 'Our mock AI engine simulates repo quality, consistency, and competitive coding signal.' },
  { title: 'Get Score', copy: 'Receive a focused report with strengths, gaps, and next-step recommendations.' },
]

const features = [
  'AI Code Analysis',
  'Skill Scoring',
  'Weakness Detection',
  'Portfolio Summary',
]

function LandingPage() {
  const { navigate } = useRoute()

  return (
    <Shell>
      <section className="mx-auto grid min-h-[calc(100vh-92px)] max-w-7xl items-center gap-12 px-6 pb-20 pt-6 lg:grid-cols-[1.05fr_0.95fr] lg:px-10">
        <div className="animate-rise">
          <p className="mb-5 inline-flex rounded-full border border-cyan-200/15 bg-cyan-200/8 px-4 py-2 text-sm font-medium text-cyan-100/85">
            Reputation intelligence for modern developers
          </p>
          <h1 className="max-w-3xl font-display text-5xl font-semibold tracking-tight text-white sm:text-6xl lg:text-7xl">
            Know Your <span className="text-gradient">Real Developer Score</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
            AI-powered analysis of your GitHub and coding skills with a clean signal on execution, consistency, and growth potential.
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <button
              type="button"
              onClick={() => navigate('/analyze')}
              className="aurora-ring glass-card rounded-full px-7 py-4 text-center text-sm font-semibold text-white transition hover:-translate-y-1"
            >
              Analyze Now
            </button>
            <button
              type="button"
              onClick={() => navigate('/dashboard')}
              className="rounded-full border border-white/10 px-7 py-4 text-center text-sm font-semibold text-slate-200 transition hover:border-white/20 hover:bg-white/6"
            >
              View Sample Dashboard
            </button>
          </div>
        </div>

        <div className="animate-float">
          <div className="glass-card aurora-ring rounded-[36px] p-6 sm:p-8">
            <div className="rounded-[28px] border border-white/10 bg-slate-950/35 p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm uppercase tracking-[0.3em] text-slate-400">Live Snapshot</p>
                  <p className="mt-3 font-display text-3xl font-semibold text-white">Developer signal, simplified.</p>
                </div>
                <div className="rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1 text-xs font-semibold text-emerald-100">
                  Mock AI
                </div>
              </div>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5">
                  <p className="text-sm text-slate-400">Overall score</p>
                  <p className="mt-4 font-display text-5xl font-bold text-white">78</p>
                  <p className="mt-2 text-sm text-cyan-100">High potential</p>
                </div>
                <div className="space-y-4 rounded-3xl border border-white/10 bg-white/[0.03] p-5">
                  <div>
                    <div className="mb-2 flex justify-between text-sm text-slate-300">
                      <span>GitHub signal</span>
                      <span>80</span>
                    </div>
                    <div className="h-2 rounded-full bg-white/8">
                      <div className="h-full w-[80%] rounded-full bg-gradient-to-r from-cyan-300 to-emerald-300" />
                    </div>
                  </div>
                  <div>
                    <div className="mb-2 flex justify-between text-sm text-slate-300">
                      <span>Problem solving</span>
                      <span>75</span>
                    </div>
                    <div className="h-2 rounded-full bg-white/8">
                      <div className="h-full w-[75%] rounded-full bg-gradient-to-r from-amber-300 to-orange-300" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                {['Strong React skills', 'Consistent commits', 'Needs deeper DSA'].map((tag) => (
                  <div key={tag} className="rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-slate-200">
                    {tag}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <SectionHeading
          eyebrow="How It Works"
          title="A three-step scan built for hiring signal."
          description="We keep the flow intentionally light so users get feedback fast without creating friction."
        />
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {steps.map((step, index) => (
            <div key={step.title} className="glass-card rounded-[30px] p-6">
              <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 font-display text-xl font-semibold text-white">
                0{index + 1}
              </div>
              <h3 className="font-display text-2xl font-semibold text-white">{step.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-300">{step.copy}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]">
          <SectionHeading
            eyebrow="Features"
            title="Everything an MVP needs to feel useful from day one."
            description="Built to evolve into deeper AI scoring later without changing the core experience."
          />
          <div className="grid gap-4 sm:grid-cols-2">
            {features.map((feature) => (
              <div key={feature} className="glass-card rounded-[28px] p-6">
                <p className="text-sm uppercase tracking-[0.3em] text-slate-500">Capability</p>
                <h3 className="mt-6 font-display text-2xl font-semibold text-white">{feature}</h3>
                <p className="mt-3 text-sm leading-7 text-slate-300">
                  Clean, focused reporting so developers understand where they stand and what to improve next.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="glass-card rounded-[36px] p-8 lg:p-12">
          <SectionHeading
            eyebrow="Why DevScore"
            title="A trust layer for developers who want their work to speak clearly."
            description="Resumes and vanity metrics miss the real story. DevScore turns public signals into a simple reputation snapshot that can guide candidates, recruiters, and teams."
          />
        </div>
      </section>

      <footer className="mx-auto flex max-w-7xl flex-col gap-4 px-6 py-10 text-sm text-slate-400 sm:flex-row sm:items-center sm:justify-between lg:px-10">
        <p>DevScore MVP. Built for fast signal and future AI expansion.</p>
        <div className="flex gap-5">
          <a href="https://github.com" target="_blank" rel="noreferrer" className="transition hover:text-white">
            GitHub
          </a>
          <a href="#top" className="transition hover:text-white">
            About
          </a>
        </div>
      </footer>
    </Shell>
  )
}

export default LandingPage
